//
//  CategoryStat.swift
//  ExpenseX
//
//  Created by 方泽堃 on 12/11/23.
//

import Foundation

struct CategoryStat {
    var category: String
    var amount: Double
    var progress: Float
}
