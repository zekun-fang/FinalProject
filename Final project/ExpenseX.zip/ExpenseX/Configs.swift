//
//  Configs.swift
//  APP12
//
//  Created by 方泽堃 on 11/20/23.
//

import Foundation

class Configs{
    static let tableViewContactsID = "tableViewContactsID"
}
