//
//   Notify view controller to handle name change action             NotificationCenter.default.post(name: NSNotification.Name("ChangeNameNotification"), object: nil)         }     } } AccountInfoView.swift
//  ExpenseX
//
//  Created by 方泽堃 on 12/10/23.
//

import UIKit

class _Notify_view_controller_to_handle_name_change_action_____________NotificationCenter_default_post_name__NSNotification_Name__ChangeNameNotification____object__nil____________________AccountInfoView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
