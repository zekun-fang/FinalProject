//
//  ProgressSpinnerDelegate.swift
//  APP12
//
//  Created by 方泽堃 on 11/20/23.
//

import Foundation

protocol ProgressSpinnerDelegate{
    func showActivityIndicator()
    func hideActivityIndicator()
}
